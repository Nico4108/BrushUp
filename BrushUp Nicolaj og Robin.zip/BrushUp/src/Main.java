import java.io.IOException;

public class Main
{
    public static void main(String[] args) throws IOException {
        GroceryList groceryList = new GroceryList();
        groceryList.groceryList();

        GroceryList2 groceryList2 = new GroceryList2();
        //groceryList2.groceryList2();
    }
}
